#include "Mapbound.h"
Mapbound::Mapbound(Vector2 position, float recWidth, float recHeight):
worldPosition(position),
width(recWidth),
height(recHeight)
{

}