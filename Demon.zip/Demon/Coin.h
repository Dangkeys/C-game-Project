#include "raylib.h"
#include "Pickups.h"

class Coin: public Pickups
{
public:
    Coin();
private:
};

